% This is the README for the experiment bandwidthExtension

% Created on 22-May-2019 by lagrange

% Purpose:

% Reference:

% Licence:

                                                         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        Getting started with your experiment based on expLanes          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This is short introduction to describe the main component of your
% experiment.

% Please have a look at the Config file. It allows you to set the general
% configuration parameters.

% Next, please have a look at the Factors file. It allows you to set the
% specific parameters that need to be set and tested for every
% configurations of your algorithm under evaluation.

% More information can be found in the documentation of expLanes:

% https://github.com/mathieulagrange/expLanes/blob/gh-pages/doc/expLanesDocumentation.pdf
